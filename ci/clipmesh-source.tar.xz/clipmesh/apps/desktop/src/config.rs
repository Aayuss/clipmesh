use anyhow::{anyhow, Context, Result};
use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine};
use clipmesh_core::MasterKey;
use directories::ProjectDirs;
use serde::{Deserialize, Serialize};
use std::{fs, net::SocketAddr, path::PathBuf};
use url::Url;
use uuid::Uuid;

pub const DISCOVERY_PORT: u16 = 41473;
pub const DEFAULT_TCP_PORT: u16 = 41474;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    pub schema: u8,
    pub device_id: Uuid,
    pub device_name: String,
    pub space_id: Uuid,
    pub tcp_port: u16,
    pub max_payload_bytes: usize,
    pub send_enabled: bool,
    pub receive_enabled: bool,
    pub exclusions: Vec<String>,
    pub static_peers: Vec<SocketAddr>,
}

impl Config {
    pub fn new(name: String) -> Self {
        Self {
            schema: 1,
            device_id: Uuid::new_v4(),
            device_name: name,
            space_id: Uuid::new_v4(),
            tcp_port: DEFAULT_TCP_PORT,
            max_payload_bytes: clipmesh_core::payload::DEFAULT_MAX_PAYLOAD_BYTES,
            send_enabled: true,
            receive_enabled: true,
            exclusions: default_exclusions(),
            static_peers: Vec::new(),
        }
    }

    pub fn joined(name: String, space_id: Uuid) -> Self {
        let mut cfg = Self::new(name);
        cfg.space_id = space_id;
        cfg
    }

    pub fn path() -> Result<PathBuf> {
        let dirs = ProjectDirs::from("dev", "ClipMesh", "ClipMesh")
            .ok_or_else(|| anyhow!("could not resolve application config directory"))?;
        Ok(dirs.config_dir().join("config.json"))
    }

    pub fn cache_dir() -> Result<PathBuf> {
        let dirs = ProjectDirs::from("dev", "ClipMesh", "ClipMesh")
            .ok_or_else(|| anyhow!("could not resolve application cache directory"))?;
        Ok(dirs.cache_dir().to_path_buf())
    }

    pub fn load() -> Result<Self> {
        let path = Self::path()?;
        let bytes = fs::read(&path).with_context(|| format!("read {}", path.display()))?;
        let cfg: Self = serde_json::from_slice(&bytes)?;
        if cfg.schema != 1 { return Err(anyhow!("unsupported config schema")); }
        Ok(cfg)
    }

    pub fn save(&self) -> Result<()> {
        let path = Self::path()?;
        if let Some(parent) = path.parent() { fs::create_dir_all(parent)?; }
        let temp = path.with_extension("json.tmp");
        fs::write(&temp, serde_json::to_vec_pretty(self)?)?;
        if path.exists() { fs::remove_file(&path)?; }
        fs::rename(temp, path)?;
        Ok(())
    }

    pub fn pairing_uri(&self, master: &MasterKey) -> String {
        let key = URL_SAFE_NO_PAD.encode(master.0);
        let mut url = Url::parse("clipmesh://pair").expect("static URL");
        url.query_pairs_mut()
            .append_pair("v", "1")
            .append_pair("space", &self.space_id.to_string())
            .append_pair("key", &key);
        url.to_string()
    }

    pub fn parse_pairing_uri(uri: &str) -> Result<(Uuid, MasterKey)> {
        let url = Url::parse(uri.trim()).context("invalid pairing URI")?;
        if url.scheme() != "clipmesh" || url.host_str() != Some("pair") {
            return Err(anyhow!("not a ClipMesh pairing URI"));
        }
        let mut version=None; let mut space=None; let mut key=None;
        for (k,v) in url.query_pairs() {
            match k.as_ref() {
                "v" => version=Some(v.into_owned()),
                "space" => space=Some(v.into_owned()),
                "key" => key=Some(v.into_owned()),
                _ => {}
            }
        }
        if version.as_deref()!=Some("1") { return Err(anyhow!("unsupported pairing version")); }
        let space_id=Uuid::parse_str(space.as_deref().ok_or_else(|| anyhow!("missing space"))?)?;
        let raw=URL_SAFE_NO_PAD.decode(key.as_deref().ok_or_else(|| anyhow!("missing key"))?)?;
        Ok((space_id, MasterKey::from_slice(&raw)?))
    }
}

pub fn default_exclusions() -> Vec<String> {
    [
        "1password", "bitwarden", "keepass", "keepassxc", "proton pass",
        "lastpass", "dashlane", "enpass", "macos passwords", "passwords",
        "windows credential manager", "keychain access", "clipmesh"
    ].into_iter().map(str::to_owned).collect()
}
