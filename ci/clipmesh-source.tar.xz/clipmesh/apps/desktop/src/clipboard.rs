use crate::{config::Config, exclusions};
use anyhow::{Context, Result};
use clipmesh_core::{ClipPayload, FilePayload, Representation};
use clipboard_rs::{
    common::RustImage, Clipboard, ClipboardContent, ClipboardContext, ClipboardHandler,
    ClipboardWatcher, ClipboardWatcherContext, ContentFormat, RustImageData,
};
use parking_lot::Mutex;
use std::{
    fs,
    path::{Path, PathBuf},
    sync::Arc,
};
use tokio::sync::mpsc;
use tracing::{debug, warn};
use url::Url;
use uuid::Uuid;

pub struct ClipboardState {
    suppressed: Mutex<Option<[u8; 32]>>,
}

impl ClipboardState {
    pub fn new() -> Self { Self { suppressed: Mutex::new(None) } }
    pub fn suppress(&self, fingerprint: [u8; 32]) { *self.suppressed.lock()=Some(fingerprint); }
    fn consume_if_suppressed(&self, fingerprint: &[u8; 32]) -> bool {
        let mut guard=self.suppressed.lock();
        if guard.as_ref()==Some(fingerprint) { *guard=None; true } else { false }
    }
}

struct Handler {
    ctx: ClipboardContext,
    cfg: Config,
    state: Arc<ClipboardState>,
    tx: mpsc::UnboundedSender<ClipPayload>,
}

impl ClipboardHandler for Handler {
    fn on_clipboard_change(&mut self) {
        if !self.cfg.send_enabled { return; }
        match read_payload(&self.ctx, &self.cfg) {
            Ok(Some(payload)) => {
                match payload.stable_fingerprint() {
                    Ok(fp) if self.state.consume_if_suppressed(&fp) => {
                        debug!("suppressed remote clipboard echo");
                    }
                    Ok(_) => { let _=self.tx.send(payload); }
                    Err(e) => warn!(error=%e, "could not fingerprint clipboard"),
                }
            }
            Ok(None) => {}
            Err(e) => warn!(error=%e, "clipboard read failed"),
        }
    }
}

pub fn spawn_watcher(cfg: Config, state: Arc<ClipboardState>, tx: mpsc::UnboundedSender<ClipPayload>) -> Result<()> {
    let ctx=ClipboardContext::new().map_err(|e| anyhow::anyhow!(e.to_string()))?;
    let handler=Handler{ctx,cfg,state,tx};
    let mut watcher=ClipboardWatcherContext::new().map_err(|e| anyhow::anyhow!(e.to_string()))?;
    watcher.add_handler(handler);
    std::thread::Builder::new().name("clipmesh-clipboard-watch".into()).spawn(move || {
        watcher.start_watch();
    })?;
    Ok(())
}

fn read_payload(ctx: &ClipboardContext, cfg: &Config) -> Result<Option<ClipPayload>> {
    let source=exclusions::active_app();
    if exclusions::is_excluded(source.as_deref(), &cfg.exclusions) {
        debug!(source=?source, "clipboard source excluded");
        return Ok(None);
    }

    let mut p=ClipPayload::new();
    p.source_app=source;

    if ctx.has(ContentFormat::Text) {
        if let Ok(v)=ctx.get_text() { if !v.is_empty() { p.representations.push(Representation::from_bytes("text/plain; charset=utf-8",v.as_bytes())); } }
    }
    if ctx.has(ContentFormat::Html) {
        if let Ok(v)=ctx.get_html() { if !v.is_empty() { p.representations.push(Representation::from_bytes("text/html; charset=utf-8",v.as_bytes())); } }
    }
    if ctx.has(ContentFormat::Rtf) {
        if let Ok(v)=ctx.get_rich_text() { if !v.is_empty() { p.representations.push(Representation::from_bytes("text/rtf",v.as_bytes())); } }
    }
    if ctx.has(ContentFormat::Image) {
        if let Ok(img)=ctx.get_image() {
            if let Ok(png)=img.to_png() {
                p.representations.push(Representation::from_bytes("image/png", png.get_bytes()));
            }
        }
    }
    if ctx.has(ContentFormat::Files) {
        if let Ok(paths)=ctx.get_files() {
            let mut running=0usize;
            for raw in paths {
                let path=normalize_file_path(&raw);
                if let Ok(meta)=fs::metadata(&path) {
                    if !meta.is_file() { continue; }
                    let len=meta.len() as usize;
                    if running.saturating_add(len)>cfg.max_payload_bytes { warn!(file=%path.display(), "file skipped: payload limit"); break; }
                    let data=fs::read(&path).with_context(|| format!("read clipboard file {}",path.display()))?;
                    running+=data.len();
                    let name=path.file_name().and_then(|x|x.to_str()).unwrap_or("clipboard-file").to_string();
                    p.files.push(FilePayload::from_bytes(name,&data));
                }
            }
        }
    }

    if p.representations.is_empty() && p.files.is_empty() { return Ok(None); }
    p.to_json_bytes(cfg.max_payload_bytes)?;
    Ok(Some(p))
}

fn normalize_file_path(raw: &str) -> PathBuf {
    if raw.starts_with("file:") {
        if let Ok(url)=Url::parse(raw) { if let Ok(p)=url.to_file_path() { return p; } }
    }
    PathBuf::from(raw)
}

pub fn apply_remote(payload: &ClipPayload, cfg: &Config, state: &ClipboardState, message_id: Uuid) -> Result<()> {
    if !cfg.receive_enabled { return Ok(()); }
    let ctx=ClipboardContext::new().map_err(|e| anyhow::anyhow!(e.to_string()))?;
    let mut contents: Vec<ClipboardContent>=Vec::new();

    for rep in &payload.representations {
        let bytes=rep.bytes()?;
        match rep.mime.as_str() {
            "text/plain; charset=utf-8" | "text/plain" => contents.push(ClipboardContent::Text(String::from_utf8(bytes)?)),
            "text/html; charset=utf-8" | "text/html" => contents.push(ClipboardContent::Html(String::from_utf8(bytes)?)),
            "text/rtf" => contents.push(ClipboardContent::Rtf(String::from_utf8(bytes)?)),
            "image/png" => {
                let img=RustImageData::from_bytes(&bytes).map_err(|e| anyhow::anyhow!(e.to_string()))?;
                contents.push(ClipboardContent::Image(img));
            }
            _ => {}
        }
    }

    if !payload.files.is_empty() {
        let base=Config::cache_dir()?.join("received").join(message_id.to_string());
        fs::create_dir_all(&base)?;
        let mut paths=Vec::new();
        for f in &payload.files {
            let safe=safe_filename(&f.name);
            let path=base.join(safe);
            fs::write(&path,f.bytes_verified()?)?;
            paths.push(path.to_string_lossy().into_owned());
        }
        if !paths.is_empty() { contents.push(ClipboardContent::Files(paths)); }
    }

    if contents.is_empty() { return Ok(()); }
    let fp=payload.stable_fingerprint()?;
    state.suppress(fp);
    ctx.set(contents).map_err(|e| anyhow::anyhow!(e.to_string()))?;
    Ok(())
}

fn safe_filename(name: &str) -> String {
    let base=Path::new(name).file_name().and_then(|x|x.to_str()).unwrap_or("clipboard-file");
    base.chars().map(|c| if c=='/'||c=='\\'||c=='\0' {'_'} else {c}).collect()
}
