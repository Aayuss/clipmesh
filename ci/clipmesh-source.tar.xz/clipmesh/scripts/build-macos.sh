#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v cargo >/dev/null || { echo "Install Rust first from https://rustup.rs"; exit 1; }
cargo build --release -p clipmesh

OUT="dist/macos"
APP="$OUT/ClipMesh.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp target/release/clipmesh "$APP/Contents/MacOS/clipmesh-bin"
cat > "$APP/Contents/MacOS/ClipMesh" <<'LAUNCHER'
#!/bin/sh
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
exec "$HERE/clipmesh-bin" run
LAUNCHER
chmod +x "$APP/Contents/MacOS/clipmesh-bin" "$APP/Contents/MacOS/ClipMesh"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleIdentifier</key><string>dev.clipmesh.private</string>
  <key>CFBundleName</key><string>ClipMesh</string>
  <key>CFBundleDisplayName</key><string>ClipMesh</string>
  <key>CFBundleExecutable</key><string>ClipMesh</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>0.1.0</string>
  <key>LSUIElement</key><true/>
  <key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST
cp target/release/clipmesh "$OUT/clipmesh"

# Ad-hoc sign for personal local use. Replace with Developer ID signing for distribution.
if command -v codesign >/dev/null 2>&1; then
  codesign --force --deep --sign - "$APP" || true
fi

if command -v hdiutil >/dev/null 2>&1; then
  rm -f "$OUT/ClipMesh.dmg"
  hdiutil create -volname ClipMesh -srcfolder "$APP" -ov -format UDZO "$OUT/ClipMesh.dmg"
  echo "Built: $OUT/ClipMesh.dmg"
else
  echo "Built app bundle: $APP"
fi
