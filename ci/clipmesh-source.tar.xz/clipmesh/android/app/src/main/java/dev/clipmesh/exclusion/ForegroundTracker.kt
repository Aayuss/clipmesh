package dev.clipmesh.exclusion

object ForegroundTracker {
    @Volatile var currentPackage: String? = null
}
