package dev.clipmesh

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.*
import dev.clipmesh.shizuku.ShizukuManager

class MainActivity : Activity() {
    private lateinit var settings: SettingsStore
    private lateinit var secrets: SecretStore
    private lateinit var shizuku: ShizukuManager
    private lateinit var status: TextView
    private lateinit var pairInput: EditText
    private lateinit var backgroundSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsStore(this)
        secrets = SecretStore(this)
        shizuku = ShizukuManager(this)
        requestNotificationPermission()
        render()
        consumePairingIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        consumePairingIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
    }

    override fun onDestroy() {
        shizuku.close()
        super.onDestroy()
    }

    private fun render() {
        val outer = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        outer.addView(root)

        root.addView(TextView(this).apply {
            text = "ClipMesh"
            textSize = 30f
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Private, LAN-only, encrypted clipboard sync"
            textSize = 15f
            setPadding(0, 0, 0, dp(16))
        })

        status = TextView(this).apply { textSize = 14f; setPadding(0, 0, 0, dp(12)) }
        root.addView(status)

        section(root, "Pairing")
        val deviceName = EditText(this).apply {
            hint = "Device name"
            setText(settings.deviceName)
            setSingleLine(true)
            setOnFocusChangeListener { _, focused -> if (!focused) settings.deviceName = text.toString() }
        }
        root.addView(deviceName)

        pairInput = EditText(this).apply {
            hint = "Paste clipmesh://pair?... here"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            minLines = 2
        }
        root.addView(pairInput)
        root.addView(horizontal(
            Button(this).apply { text = "Join"; setOnClickListener { joinSpace() } },
            Button(this).apply { text = "Create new"; setOnClickListener { createSpace() } }
        ))
        root.addView(Button(this).apply {
            text = "Copy this device's pairing code"
            setOnClickListener { copyPairingCode() }
        })

        section(root, "Background sync")
        backgroundSwitch = toggle(root, "Background auto-sync", settings.backgroundSync) {
            settings.backgroundSync = it
            if (it) startSync() else stopSync()
        }
        toggle(root, "Send clipboard", settings.sendEnabled) { settings.sendEnabled = it }
        toggle(root, "Receive clipboard", settings.receiveEnabled) { settings.receiveEnabled = it }
        toggle(root, "Start after reboot", settings.runAtBoot) { settings.runAtBoot = it }
        toggle(root, "Compatibility watchdog (more battery)", settings.compatibilityWatchdog) {
            settings.compatibilityWatchdog = it
            toast("Restart background sync for this change to take effect")
        }

        section(root, "Content")
        toggle(root, "Text + HTML", settings.syncText) { settings.syncText = it }
        toggle(root, "Images / screenshots", settings.syncImages) { settings.syncImages = it }
        toggle(root, "Files", settings.syncFiles) { settings.syncFiles = it }

        section(root, "Android background clipboard access")
        root.addView(TextView(this).apply {
            text = "Recommended: Shizuku. It lets the background service read/write the clipboard without continuous polling. On non-rooted Android, Shizuku may need to be started again after a reboot."
            textSize = 14f
        })
        root.addView(Button(this).apply {
            text = "Request Shizuku permission"
            setOnClickListener {
                if (!shizuku.isAvailable()) toast("Start/install Shizuku first")
                else if (shizuku.hasPermission()) toast("Shizuku already authorized")
                else shizuku.requestPermission()
            }
        })

        section(root, "Privacy - app exclusions")
        root.addView(Button(this).apply {
            text = "Choose excluded apps"
            setOnClickListener { startActivity(Intent(this@MainActivity, ExclusionActivity::class.java)) }
        })
        root.addView(Button(this).apply {
            text = "Open Accessibility settings for exclusion helper"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        section(root, "LAN troubleshooting")
        val peers = EditText(this).apply {
            hint = "Optional static peers, one per line: 192.168.1.10:41474"
            minLines = 3
            setText(settings.staticPeers.joinToString("\n"))
        }
        root.addView(peers)
        root.addView(Button(this).apply {
            text = "Save static peers"
            setOnClickListener {
                settings.staticPeers = peers.text.lines().map { it.trim() }.filter { it.isNotBlank() }.toSet()
                toast("Saved")
            }
        })

        root.addView(TextView(this).apply {
            text = "Security defaults: encryption is mandatory; internet/relay mode does not exist; no analytics; no cloud account; no clipboard history database. Pairing codes contain the shared space secret - treat them like a password."
            textSize = 13f
            setPadding(0, dp(22), 0, 0)
        })

        setContentView(outer)
        refreshStatus()
    }

    private fun consumePairingIntent(incoming: Intent?) {
        val data = incoming?.dataString ?: return
        if (data.startsWith("clipmesh://pair")) {
            pairInput.setText(data)
            toast("Pairing code received locally. Tap Join to confirm.")
        }
    }

    private fun createSpace() {
        if (settings.spaceId != null && secrets.loadSpaceKey() != null) {
            toast("Already paired. Clear app data if you intentionally want a new space.")
            return
        }
        val data = Pairing.createSpace(settings.deviceName)
        settings.spaceId = data.spaceId
        secrets.saveSpaceKey(data.key)
        toast("New private space created")
        refreshStatus()
    }

    private fun joinSpace() {
        if (settings.spaceId != null && secrets.loadSpaceKey() != null) {
            toast("Already paired. Clear app data before joining a different space.")
            return
        }
        runCatching { Pairing.parse(pairInput.text.toString()) }
            .onSuccess {
                settings.spaceId = it.spaceId
                secrets.saveSpaceKey(it.key)
                toast("Joined private space")
                refreshStatus()
            }.onFailure { toast(it.message ?: "Invalid pairing code") }
    }

    private fun copyPairingCode() {
        val space = settings.spaceId ?: run { toast("Create or join a space first"); return }
        val key = secrets.loadSpaceKey() ?: run { toast("Space key missing"); return }
        val uri = Pairing.toUri(Pairing.PairingData(space, key, settings.deviceName))
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ClipMesh pairing code", uri))
        toast("Pairing code copied. It contains your secret key - share only with your own device.")
    }

    private fun startSync() {
        if (settings.spaceId == null || secrets.loadSpaceKey() == null) {
            backgroundSwitch.isChecked = false
            settings.backgroundSync = false
            toast("Pair this device first")
            return
        }
        val intent = Intent(this, SyncService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        refreshStatus()
    }

    private fun stopSync() {
        stopService(Intent(this, SyncService::class.java))
        refreshStatus()
    }

    private fun refreshStatus() {
        val paired = settings.spaceId != null && secrets.loadSpaceKey() != null
        val sh = when {
            !shizuku.isAvailable() -> "not running"
            shizuku.hasPermission() -> "authorized"
            else -> "permission needed"
        }
        status.text = "Paired: ${if (paired) "yes" else "no"}   |   Shizuku: $sh\nService: ${SyncService.status}"
    }

    private fun section(root: LinearLayout, title: String) {
        root.addView(TextView(this).apply {
            text = title
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(22), 0, dp(8))
        })
    }

    private fun toggle(root: LinearLayout, label: String, value: Boolean, changed: (Boolean) -> Unit): Switch {
        val sw = Switch(this).apply {
            text = label
            isChecked = value
            setPadding(0, dp(5), 0, dp(5))
            setOnCheckedChangeListener { _, checked -> changed(checked) }
        }
        root.addView(sw)
        return sw
    }

    private fun horizontal(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 200)
        }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
