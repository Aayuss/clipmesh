package dev.clipmesh

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import dev.clipmesh.clipboard.ClipboardBridge
import dev.clipmesh.network.NetworkEngine
import dev.clipmesh.shizuku.ShizukuManager
import kotlinx.coroutines.*

class SyncService : Service() {
    companion object {
        const val ACTION_STOP = "dev.clipmesh.STOP"
        private const val CHANNEL_ID = "clipmesh_sync"
        private const val NOTIFICATION_ID = 41474
        @Volatile var status: String = "Stopped"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var settings: SettingsStore
    private var network: NetworkEngine? = null
    private var clipboard: ClipboardBridge? = null
    private var shizuku: ShizukuManager? = null
    private var watchdog: Job? = null

    override fun onCreate() {
        super.onCreate()
        settings = SettingsStore(this)
        createChannel()
        startForeground(NOTIFICATION_ID, notification("Starting encrypted LAN sync…"))
        startEngine()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            settings.backgroundSync = false
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        watchdog?.cancel()
        clipboard?.stop()
        network?.stop()
        shizuku?.close()
        scope.cancel()
        status = "Stopped"
        super.onDestroy()
    }

    private fun startEngine() {
        val space = settings.spaceId
        val key = SecretStore(this).loadSpaceKey()
        if (space == null || key == null) {
            status = "Not paired"
            updateNotification(status)
            stopSelf()
            return
        }

        val sh = ShizukuManager(this)
        shizuku = sh
        lateinit var bridge: ClipboardBridge
        val net = NetworkEngine(
            settings = settings,
            masterKey = key,
            onRemoteClip = { payload -> bridge.applyRemote(payload) },
            onStatus = { text ->
                status = text
                updateNotification(text)
            }
        )
        bridge = ClipboardBridge(this, settings, sh) { payload -> net.sendClipboard(payload) }
        clipboard = bridge
        network = net
        bridge.start()
        net.start()

        // Optional compatibility watchdog: OFF by default. It runs only while the
        // screen is interactive and exists for OEMs that suppress clipboard callbacks.
        if (settings.compatibilityWatchdog) {
            val power = getSystemService(Context.POWER_SERVICE) as PowerManager
            watchdog = scope.launch {
                while (isActive) {
                    if (power.isInteractive) bridge.captureNowForWatchdog()
                    delay(5_000L)
                }
            }
        }
        status = if (sh.hasPermission()) "LAN sync active - Shizuku ready" else "LAN sync active - Shizuku permission needed for background reads"
        updateNotification(status)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "ClipMesh background sync", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Keeps the private LAN clipboard bridge available in the background"
                    setShowBadge(false)
                }
            )
        }
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, SyncService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentTitle("ClipMesh")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop).build())
            .build()
    }

    private fun updateNotification(text: String) {
        runCatching { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text)) }
    }
}
