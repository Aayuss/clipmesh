package dev.clipmesh.shizuku

import android.app.Application
import android.content.ClipData
import android.content.ClipDescription
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.FileOutputStream

/**
 * Adapted from UniClipboard/UniClip's MIT-licensed shizuku-clipboard module.
 * See THIRD_PARTY_NOTICES.md and licenses/UNICLIP-MIT.txt in the repository root.
 */
class ClipboardUserService : IClipboardUserService.Stub() {
    companion object {
        private const val TAG = "ClipMeshShizuku"
        private const val SHELL_PACKAGE = "com.android.shell"
        private const val MAX_ITEM_BYTES = 44L * 1024L * 1024L
        @Volatile private var clipboardService: Any? = null

        init {
            if (android.os.Process.myUid() == 0) {
                runCatching {
                    android.system.Os.setgid(2000)
                    android.system.Os.setuid(2000)
                }
            }
        }

        private fun application(): Application? = runCatching {
            Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null) as? Application
        }.getOrNull() ?: runCatching {
            Class.forName("android.app.AppGlobals").getMethod("getInitialApplication").invoke(null) as? Application
        }.getOrNull()

        private fun clipboard(): Any? {
            clipboardService?.let { return it }
            return runCatching {
                val sm = Class.forName("android.os.ServiceManager")
                val binder = sm.getMethod("getService", String::class.java).invoke(null, "clipboard") as? IBinder ?: return null
                val stub = Class.forName("android.content.IClipboard\$Stub")
                stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder).also { clipboardService = it }
            }.onFailure { Log.e(TAG, "Unable to obtain clipboard binder", it) }.getOrNull()
        }
    }

    @Volatile private var lastClip: ClipData? = null

    override fun init(callerToken: IBinder) {
        runCatching { callerToken.linkToDeath({ destroy() }, 0) }
    }

    override fun getPrimaryClipJson(): String {
        val clip = invokeClipboard("getPrimaryClip") as? ClipData ?: return ""
        if (clip.itemCount == 0) return ""
        lastClip = clip
        val description = clip.description
        val items = JSONArray()
        for (i in 0 until clip.itemCount) {
            val item = clip.getItemAt(i)
            val uri = item.uri
            val resolvedMime = uri?.let { u -> runCatching { application()?.contentResolver?.getType(u) }.getOrNull() }
            val mime = resolvedMime ?: description?.let { d ->
                (0 until d.mimeTypeCount).map { d.getMimeType(it) }.firstOrNull { m ->
                    if (uri != null) !m.startsWith("text/") else m.startsWith("text/")
                } ?: if (d.mimeTypeCount > 0) d.getMimeType(0) else null
            } ?: if (item.text != null) "text/plain" else "application/octet-stream"
            items.put(JSONObject().apply {
                put("index", i)
                put("mime", mime)
                if (item.text != null) put("text", item.text.toString())
                if (item.htmlText != null) put("html", item.htmlText)
                if (uri != null) {
                    put("uri", uri.toString())
                    put("name", queryDisplayName(uri).ifBlank { "clipboard-$i" })
                }
            })
        }
        val extras = description?.extras
        val sensitive = if (Build.VERSION.SDK_INT >= 33) {
            extras?.getBoolean(ClipDescription.EXTRA_IS_SENSITIVE, false) ?: false
        } else {
            extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) ?: false
        }
        return JSONObject().put("sensitive", sensitive).put("items", items).toString()
    }

    override fun copyPrimaryClipItemToFile(index: Int, destination: ParcelFileDescriptor): Boolean {
        val clip = lastClip ?: (invokeClipboard("getPrimaryClip") as? ClipData) ?: return false
        if (index !in 0 until clip.itemCount) return false
        val uri = clip.getItemAt(index).uri ?: return false
        val resolver = application()?.contentResolver ?: return false
        return runCatching {
            resolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destination.fileDescriptor).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        total += n
                        if (total > MAX_ITEM_BYTES) return false
                        output.write(buffer, 0, n)
                    }
                }
            } ?: return false
            true
        }.getOrDefault(false)
    }

    override fun setPrimaryClipText(text: String): Boolean =
        invokeClipboard("setPrimaryClip", ClipData.newPlainText("ClipMesh", text)) != null

    override fun destroy() {
        lastClip = null
        clipboardService = null
        kotlin.system.exitProcess(0)
    }

    private fun queryDisplayName(uri: Uri): String {
        val resolver = application()?.contentResolver ?: return ""
        return runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0).orEmpty() else ""
            }.orEmpty()
        }.getOrDefault("")
    }

    private fun invokeClipboard(methodName: String, clipData: ClipData? = null): Any? {
        val target = clipboard() ?: return null
        val methods = target.javaClass.methods.filter { it.name == methodName }.sortedByDescending { it.parameterCount }
        for (method in methods) {
            val args = arrayOfNulls<Any>(method.parameterCount)
            var stringIndex = 0
            var supported = true
            method.parameterTypes.forEachIndexed { i, type ->
                args[i] = when {
                    ClipData::class.java.isAssignableFrom(type) -> clipData
                    type == String::class.java -> if (stringIndex++ == 0) SHELL_PACKAGE else null
                    type == Int::class.javaPrimitiveType || type == Int::class.java -> 0
                    type == Long::class.javaPrimitiveType || type == Long::class.java -> 0L
                    type == Boolean::class.javaPrimitiveType || type == Boolean::class.java -> false
                    else -> { supported = false; null }
                }
            }
            if (!supported || (methodName == "setPrimaryClip" && clipData == null)) continue
            try {
                val result = method.invoke(target, *args)
                return result ?: if (method.returnType == Void.TYPE) true else null
            } catch (error: Exception) {
                Log.d(TAG, "Clipboard signature did not match: ${method.parameterTypes.joinToString { it.simpleName }}")
            }
        }
        return null
    }
}
