package dev.clipmesh.exclusion

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Privacy-minimized helper used only for source-app exclusions.
 * The service configuration explicitly disables window-content retrieval.
 */
class ExclusionAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString()
        if (!pkg.isNullOrBlank()) ForegroundTracker.currentPackage = pkg
    }
    override fun onInterrupt() = Unit
}
