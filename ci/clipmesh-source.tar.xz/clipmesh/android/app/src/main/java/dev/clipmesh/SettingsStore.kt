package dev.clipmesh

import android.content.Context
import android.os.Build
import java.util.UUID

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("clipmesh_settings", Context.MODE_PRIVATE)

    var deviceId: UUID
        get() = UUID.fromString(prefs.getString("device_id", null) ?: UUID.randomUUID().also {
            prefs.edit().putString("device_id", it.toString()).apply()
        }.toString())
        set(value) = prefs.edit().putString("device_id", value.toString()).apply()

    var deviceName: String
        get() = prefs.getString("device_name", null) ?: (Build.MANUFACTURER + " " + Build.MODEL).trim()
        set(value) = prefs.edit().putString("device_name", value.trim()).apply()

    var spaceId: UUID?
        get() = prefs.getString("space_id", null)?.let { runCatching { UUID.fromString(it) }.getOrNull() }
        set(value) = prefs.edit().putString("space_id", value?.toString()).apply()

    var backgroundSync: Boolean
        get() = prefs.getBoolean("background_sync", false)
        set(value) = prefs.edit().putBoolean("background_sync", value).apply()

    var sendEnabled: Boolean
        get() = prefs.getBoolean("send_enabled", true)
        set(value) = prefs.edit().putBoolean("send_enabled", value).apply()

    var receiveEnabled: Boolean
        get() = prefs.getBoolean("receive_enabled", true)
        set(value) = prefs.edit().putBoolean("receive_enabled", value).apply()

    var runAtBoot: Boolean
        get() = prefs.getBoolean("run_at_boot", true)
        set(value) = prefs.edit().putBoolean("run_at_boot", value).apply()

    var syncText: Boolean
        get() = prefs.getBoolean("sync_text", true)
        set(value) = prefs.edit().putBoolean("sync_text", value).apply()

    var syncImages: Boolean
        get() = prefs.getBoolean("sync_images", true)
        set(value) = prefs.edit().putBoolean("sync_images", value).apply()

    var syncFiles: Boolean
        get() = prefs.getBoolean("sync_files", true)
        set(value) = prefs.edit().putBoolean("sync_files", value).apply()

    var compatibilityWatchdog: Boolean
        get() = prefs.getBoolean("compat_watchdog", false)
        set(value) = prefs.edit().putBoolean("compat_watchdog", value).apply()

    var excludedPackages: Set<String>
        get() = prefs.getStringSet("excluded_packages", DEFAULT_EXCLUSIONS)?.toSet() ?: DEFAULT_EXCLUSIONS
        set(value) = prefs.edit().putStringSet("excluded_packages", value.map { it.trim() }.filter { it.isNotBlank() }.toSet()).apply()

    var staticPeers: Set<String>
        get() = prefs.getStringSet("static_peers", emptySet())?.toSet() ?: emptySet()
        set(value) = prefs.edit().putStringSet("static_peers", value.map { it.trim() }.filter { it.isNotBlank() }.toSet()).apply()

    companion object {
        val DEFAULT_EXCLUSIONS = setOf(
            "dev.clipmesh",
            "com.onepassword.android",
            "com.x8bit.bitwarden",
            "com.keepass2android.keepass2android",
            "com.proton.pass",
            "com.lastpass.lpandroid",
            "com.dashlane",
            "com.enpass.mobile"
        )
    }
}
