package dev.clipmesh.clipboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import dev.clipmesh.SettingsStore
import dev.clipmesh.crypto.Crypto
import dev.clipmesh.exclusion.ForegroundTracker
import dev.clipmesh.model.ClipPayload
import dev.clipmesh.model.PortableFile
import dev.clipmesh.model.Representation
import dev.clipmesh.shizuku.ShizukuManager
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

class ClipboardBridge(
    private val context: Context,
    private val settings: SettingsStore,
    private val shizuku: ShizukuManager,
    private val onLocalClip: (ClipPayload) -> Unit
) {
    private val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    private val main = Handler(Looper.getMainLooper())
    private val suppressedFingerprint = AtomicReference<String?>(null)
    private val lastWatchdogFingerprint = AtomicReference<String?>(null)
    private val captureExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "ClipMesh-ClipboardCapture").apply { isDaemon = true } }
    private var started = false
    private val listener = ClipboardManager.OnPrimaryClipChangedListener { captureAsync(fromWatchdog = false) }

    fun start() {
        if (started) return
        started = true
        main.post { clipboard.addPrimaryClipChangedListener(listener) }
    }

    fun stop() {
        if (!started) return
        started = false
        main.post { clipboard.removePrimaryClipChangedListener(listener) }
        captureExecutor.shutdownNow()
    }

    fun captureNowForWatchdog() = captureAsync(fromWatchdog = true)

    private fun captureAsync(fromWatchdog: Boolean) {
        if (!started || !settings.sendEnabled) return
        val sourcePackage = ForegroundTracker.currentPackage
        if (sourcePackage != null && settings.excludedPackages.contains(sourcePackage)) return
        captureExecutor.execute {
            val payload = readCurrent(sourcePackage) ?: return@execute
            val fp = payload.stableFingerprint()
            if (suppressedFingerprint.compareAndSet(fp, null)) {
                lastWatchdogFingerprint.set(fp)
                return@execute
            }
            if (fromWatchdog && lastWatchdogFingerprint.getAndSet(fp) == fp) return@execute
            lastWatchdogFingerprint.set(fp)
            onLocalClip(payload)
        }
    }

    private fun readCurrent(sourcePackage: String?): ClipPayload? {
        // Shizuku is preferred because Android restricts normal background clipboard reads.
        val shizukuJson = if (shizuku.hasPermission()) shizuku.readSnapshotJson() else ""
        if (shizukuJson.isNotBlank()) return readShizukuSnapshot(shizukuJson, sourcePackage)

        // Fallback works while ClipMesh has input focus and on some OEM/Android combinations.
        val clip = clipboard.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        val reps = mutableListOf<Representation>()
        val text = clip.getItemAt(0).coerceToText(context)?.toString()
        if (settings.syncText && !text.isNullOrEmpty()) reps += Representation("text/plain;charset=utf-8", text.toByteArray())
        return ClipPayload(reps, sourceApp = sourcePackage).takeIf { it.representations.isNotEmpty() }
    }

    private fun readShizukuSnapshot(json: String, sourcePackage: String?): ClipPayload? {
        val o = runCatching { JSONObject(json) }.getOrNull() ?: return null
        if (o.optBoolean("sensitive", false)) return null
        val items = o.optJSONArray("items") ?: return null
        val reps = mutableListOf<Representation>()
        val files = mutableListOf<PortableFile>()
        var rawBinaryBytes = 0L
        for (i in 0 until items.length()) {
            val item = items.getJSONObject(i)
            val mime = item.optString("mime", "application/octet-stream")
            val text = item.optString("text").takeIf { it.isNotEmpty() }
            val html = item.optString("html").takeIf { it.isNotEmpty() }
            if (settings.syncText && text != null && reps.none { it.mime.startsWith("text/plain") }) {
                reps += Representation("text/plain;charset=utf-8", text.toByteArray())
            }
            if (settings.syncText && html != null && reps.none { it.mime == "text/html" }) {
                reps += Representation("text/html", html.toByteArray())
            }
            if (item.has("uri")) {
                val isImage = mime.lowercase(Locale.ROOT).startsWith("image/")
                if ((isImage && !settings.syncImages) || (!isImage && !settings.syncFiles)) continue
                val temp = File(context.cacheDir, "outgoing/${System.nanoTime()}-$i")
                if (shizuku.copyItem(item.getInt("index"), temp)) {
                    val bytes = temp.readBytes()
                    temp.delete()
                    rawBinaryBytes += bytes.size
                    if (rawBinaryBytes > 44L * 1024L * 1024L) break
                    val name = sanitizeName(item.optString("name", if (isImage) "clipboard.png" else "clipboard-$i"))
                    val hash = Crypto.hex(Crypto.sha256(bytes))
                    if (isImage && items.length() == 1) reps += Representation(mime, bytes)
                    else files += PortableFile(name, bytes, hash)
                }
            }
        }
        val payload = ClipPayload(reps, files, sourcePackage)
        return payload.takeIf { it.representations.isNotEmpty() || it.files.isNotEmpty() }
    }

    fun applyRemote(payload: ClipPayload) {
        if (!settings.receiveEnabled) return
        val remoteFingerprint = payload.stableFingerprint()
        suppressedFingerprint.set(remoteFingerprint)
        main.postDelayed({ suppressedFingerprint.compareAndSet(remoteFingerprint, null) }, 1_500L)
        val plain = payload.representations.firstOrNull { it.mime.startsWith("text/plain") }
        val html = payload.representations.firstOrNull { it.mime.startsWith("text/html") }
        val image = payload.representations.firstOrNull { it.mime.startsWith("image/") }
        // Binder connection/privileged write may block briefly, so perform it on the network/capture thread.
        if (plain != null && html == null && shizuku.hasPermission()) {
            val text = String(plain.data)
            if (shizuku.setText(text)) return
        }
        main.post {
            when {
                payload.files.isNotEmpty() -> setFiles(payload.files)
                image != null -> setSingleBinary("clipboard-${System.currentTimeMillis()}.${extension(image.mime)}", image.mime, image.data)
                plain != null -> {
                    val text = String(plain.data)
                    val htmlText = html?.let { String(it.data) }
                    if (htmlText != null) clipboard.setPrimaryClip(ClipData.newHtmlText("ClipMesh", text, htmlText))
                    else clipboard.setPrimaryClip(ClipData.newPlainText("ClipMesh", text))
                }
            }
        }
    }

    private fun setFiles(files: List<PortableFile>) {
        var clip: ClipData? = null
        files.forEach { f ->
            val file = File(context.cacheDir, "received/${uniqueName(f.name)}")
            file.parentFile?.mkdirs(); file.writeBytes(f.data)
            val mime = guessMime(f.name)
            val uri = Uri.Builder().scheme("content").authority("${context.packageName}.files")
                .appendPath(file.name).appendQueryParameter("mime", mime).appendQueryParameter("display", f.name).build()
            val item = ClipData.Item(uri)
            if (clip == null) clip = ClipData("ClipMesh files", arrayOf(mime), item) else clip!!.addItem(item)
        }
        clip?.let { clipboard.setPrimaryClip(it) }
    }

    private fun setSingleBinary(name: String, mime: String, bytes: ByteArray) {
        val file = File(context.cacheDir, "received/${uniqueName(name)}")
        file.parentFile?.mkdirs(); file.writeBytes(bytes)
        val uri = Uri.Builder().scheme("content").authority("${context.packageName}.files")
            .appendPath(file.name).appendQueryParameter("mime", mime).build()
        clipboard.setPrimaryClip(ClipData("ClipMesh", arrayOf(mime), ClipData.Item(uri)))
    }

    private fun guessMime(name: String): String = java.net.URLConnection.guessContentTypeFromName(name) ?: "application/octet-stream"
    private fun uniqueName(name: String): String = "${System.currentTimeMillis()}-${sanitizeName(name)}"
    private fun sanitizeName(name: String): String = name.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(120).ifBlank { "clipboard" }
    private fun extension(mime: String): String = when (mime.lowercase(Locale.ROOT)) {
        "image/jpeg" -> "jpg"; "image/webp" -> "webp"; "image/gif" -> "gif"; else -> "png"
    }
}
