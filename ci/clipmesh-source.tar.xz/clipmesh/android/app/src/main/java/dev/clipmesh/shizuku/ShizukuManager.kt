package dev.clipmesh.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import dev.clipmesh.BuildConfig
import rikka.shizuku.Shizuku
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class ShizukuManager(private val context: Context) {
    private val callerToken = Binder()
    @Volatile private var service: IClipboardUserService? = null
    @Volatile private var binding = false
    @Volatile private var latch = CountDownLatch(1)

    private val args: Shizuku.UserServiceArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(context.packageName, ClipboardUserService::class.java.name))
            .daemon(false)
            .processNameSuffix("clipboard")
            .debuggable(BuildConfig.DEBUG)
            .version(1)
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            binding = false
            service = binder?.let(IClipboardUserService.Stub::asInterface)
            runCatching { service?.init(callerToken) }
            latch.countDown()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            binding = false
            service = null
        }
    }

    fun isAvailable(): Boolean = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
    fun hasPermission(): Boolean = runCatching {
        isAvailable() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    fun requestPermission(requestCode: Int = 8844): Boolean {
        if (!isAvailable() || Shizuku.isPreV11()) return false
        Shizuku.requestPermission(requestCode)
        return true
    }

    fun readSnapshotJson(): String = runCatching { ensure()?.primaryClipJson.orEmpty() }.getOrDefault("")

    fun copyItem(index: Int, destination: File): Boolean {
        destination.parentFile?.mkdirs()
        val descriptor = ParcelFileDescriptor.open(
            destination,
            ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE or ParcelFileDescriptor.MODE_READ_WRITE
        )
        return try {
            ensure()?.copyPrimaryClipItemToFile(index, descriptor) == true
        } catch (_: Exception) {
            false
        } finally {
            descriptor.close()
        }
    }

    fun setText(text: String): Boolean = runCatching { ensure()?.setPrimaryClipText(text) == true }.getOrDefault(false)

    fun close() {
        if (service == null && !binding) return
        runCatching { Shizuku.unbindUserService(args, connection, true) }
        service = null
        binding = false
    }

    private fun ensure(): IClipboardUserService? {
        service?.let { return it }
        if (!hasPermission()) return null
        if (!binding) {
            binding = true
            latch = CountDownLatch(1)
            runCatching { Shizuku.bindUserService(args, connection) }.onFailure {
                binding = false
                latch.countDown()
            }
        }
        runCatching { latch.await(2, TimeUnit.SECONDS) }
        return service
    }
}
