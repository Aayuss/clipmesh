package dev.clipmesh.shizuku;

import android.os.IBinder;
import android.os.ParcelFileDescriptor;

interface IClipboardUserService {
    void init(in IBinder callerToken);
    String getPrimaryClipJson();
    boolean copyPrimaryClipItemToFile(int index, in ParcelFileDescriptor destination);
    boolean setPrimaryClipText(String text);
    void destroy();
}
